package com.example.dietplan;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.Serializable;

public class Meal implements Serializable{
    public enum MealType {
        Breakfast, Lunch, Dinner
    }

    private String _name;
    private MealType _mealType;
    private Double _calories;
    private String[] _ingredients;



    public String getName() {
        return _name;
    }
    public Double getCalories() {
        return _calories;
    }

    public String[] getIngredients() {
        return _ingredients;
    }

    public MealType getMealType() {
        return _mealType;
    }
}
