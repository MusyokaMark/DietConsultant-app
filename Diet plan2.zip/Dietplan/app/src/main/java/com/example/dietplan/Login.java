package com.example.dietplan;


import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.AsyncQueryHandler;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.BaseJsonHttpResponseHandler;

import cz.msebera.android.httpclient.Header;


public class Login extends AppCompatActivity implements View.OnClickListener {

    private EditText editTextEmail, editTextPassword;
    private TextView register, forgetpass;
    private Button login;
    private FirebaseAuth mAuth;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        register = (TextView) findViewById(R.id.register_textview);
        register.setOnClickListener(this);
        forgetpass = (TextView) findViewById(R.id.forget_password_textview);
        forgetpass.setOnClickListener(this);
        login = (Button) findViewById(R.id.loginButton);
        login.setOnClickListener(this);

        editTextEmail = (EditText) findViewById(R.id.email);
        editTextPassword = (EditText) findViewById(R.id.password);

        mAuth = FirebaseAuth.getInstance();
        try {
            System.out.println("-------------------------------hello------------------");
            loadFood();

        } catch (Exception e) {
            System.err.println(e.getMessage());
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.register_textview:
                startActivity(new Intent(this, SignUp.class));
                break;

            case R.id.forget_password_textview:
                startActivity(new Intent(this, Forgot_Password.class));
                break;

            case R.id.loginButton:
                userLogin();
                break;
        }
    }

    private void loadFood() {
        AsyncHttpClient client = new AsyncHttpClient();
        client.get("https://api.spoonacular.com/recipes/findByNutrients?minCalories=50&apiKey=3c4445d0536244488d4a3a7914765a8d", new BaseJsonHttpResponseHandler<String>() {
            @Override
            public void onSuccess(int statusCode, Header[] headers, String rawJsonResponse, String response) {
                System.out.println(rawJsonResponse);
                System.out.println("************done**************");
            }

            @Override
            public void onFailure(int statusCode, Header[] headers, Throwable throwable, String rawJsonData, String errorResponse) {
                System.out.println(errorResponse);
            }

            @Override
            protected String parseResponse(String rawJsonData, boolean isFailure) throws Throwable {
                return rawJsonData;
            }
        });
    }

    private void userLogin() {

        String email = editTextEmail.getText().toString().trim();
        String password = editTextPassword.getText().toString().trim();

        if (email.isEmpty()) {
            editTextEmail.setError("Email required");
            editTextEmail.requestFocus();
            return;
        }
        if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            editTextEmail.setError("Please provide valid email!");
            editTextEmail.requestFocus();
            return;
        }
        if (password.isEmpty()) {
            editTextPassword.setError("Password required");
            editTextPassword.requestFocus();
            return;
        }
        if (password.length() < 6) {
            editTextPassword.setError("Min password length should be 6 characters");
            editTextPassword.requestFocus();
            return;
        }
        mAuth.signInWithEmailAndPassword(email, password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if (task.isSuccessful()) {
                    FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();

                    if (user.isEmailVerified()) {
                        Toast.makeText(Login.this, "Login successfully", Toast.LENGTH_SHORT).show();
                        editTextEmail.setText(" ");
                        editTextPassword.setText(" ");
                        startActivity(new Intent(Login.this, Home.class));
                    } else {
                        user.sendEmailVerification();
                        Toast.makeText(Login.this, "Check your email to verify you account", Toast.LENGTH_LONG).show();
                    }

                } else {
                    Toast.makeText(Login.this, "Login failed check your credentials", Toast.LENGTH_LONG).show();
                }
            }
        });
    }
}

//    @Override
//    protected void onResume() {
//        super.onResume();
//        FirebaseUser currentUser = mAuth.getCurrentUser();
//        if(currentUser != null){
//            updateUI(currentUser);
//        }
//    }
//
//    @Override
//    protected void onStart() {
//        super.onStart();
//        FirebaseUser currentUser = mAuth.getCurrentUser();
//        if(currentUser != null){
//            updateUI(currentUser);
//        }
//    }
//
//    private void updateUI(FirebaseUser currentUser) {
//        Intent mainIntent = new Intent(getApplicationContext(), MainActivity.class);
//        mainIntent.putExtra("emailText",currentUser.getEmail());
//        Log.v("DATA", currentUser.getUid());
//        startActivity(mainIntent);
//    }
