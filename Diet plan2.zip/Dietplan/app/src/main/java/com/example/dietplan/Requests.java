package com.example.dietplan;

import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.BaseJsonHttpResponseHandler;

import cz.msebera.android.httpclient.Header;

public class Requests {

    private static final String apiKey= "3c4445d0536244488d4a3a7914765a8d";
    public static void getFood(){



        AsyncHttpClient client = new AsyncHttpClient();
//        String url = "https://api.spoonacular.com/recipes/" + "/information?apiKey=" + apiKey + "&includeNutrition=false";
        client.get("https://api.spoonacular.com/recipes/findByNutrients?apiKey=3c4445d0536244488d4a3a7914765a8d", new BaseJsonHttpResponseHandler<Meal>() {
            @Override
            public void onSuccess(int statusCode, Header[] headers, String rawJsonResponse, Meal response) {

            }

            @Override
            public void onFailure(int statusCode, Header[] headers, Throwable throwable, String rawJsonData, Meal errorResponse) {
                System.out.println(rawJsonData);
            }

            @Override
            protected Meal parseResponse(String rawJsonData, boolean isFailure) throws Throwable {
                System.out.println(rawJsonData);
                return null;
            }
        });

    }

    public static void main(String[] args) {
        Requests.getFood();
    }
}
