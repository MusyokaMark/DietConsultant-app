package com.example.dietplan;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.FirebaseDatabase;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.BaseJsonHttpResponseHandler;
import com.loopj.android.http.RequestHandle;
import com.loopj.android.http.RequestParams;


import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.concurrent.FutureTask;

import cz.msebera.android.httpclient.Header;
import cz.msebera.android.httpclient.entity.StringEntity;

public class SignUp extends AppCompatActivity implements View.OnClickListener {
    private EditText editTextUsername, editTextEmail, editTextPhone, editTextPassword, editTextHeight, editTextWeight;

    private RadioGroup genderRadioGroup;

    private Button registerUser ;
    private ImageView select_date;

    private RadioButton radioMale, radioFemale;
    private TextView date;
    private  Calendar c;
    private DatePickerDialog dpd;

    private FirebaseAuth mAuth;
    String gender = "";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);

        mAuth = FirebaseAuth.getInstance();

        genderRadioGroup = findViewById(R.id.genderRadioGroup);

        radioMale = (RadioButton) findViewById(R.id.radioMale);
        radioMale.setChecked(true);

        registerUser = (Button) findViewById(R.id.registerButton);

        editTextUsername = (EditText) findViewById(R.id.username);
        editTextUsername.setText("Felix");
        editTextEmail = (EditText) findViewById(R.id.email);
        editTextEmail.setText("feixmarvinonline@gmail.com");
        editTextPhone = (EditText) findViewById(R.id.phone);
        editTextPhone.setText("0748833681");
        editTextPassword = (EditText) findViewById(R.id.password);
        editTextPassword.setText("1234567");
        editTextHeight = (EditText) findViewById(R.id.height);
        editTextHeight.setText("1.5");
        editTextWeight = (EditText) findViewById(R.id.weight);
        editTextWeight.setText("50");
        registerUser.setOnClickListener(this);
        genderRadioGroup.setOnClickListener(this);


        date = (TextView) findViewById(R.id.date_of_birth);
        select_date = findViewById(R.id.select_dob);

        select_date.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                c = Calendar.getInstance();
                final int day = c.get(Calendar.DAY_OF_MONTH);
                int month = c.get(Calendar.MONTH);
                int year = c.get(Calendar.YEAR);

                dpd = new DatePickerDialog(SignUp.this, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                        date.setText(dayOfMonth + "/" + (month + 1) + "/" + year);
                    }
                }, day, month, year);
                dpd.show();
            }


        });

        date.setText(12 + "/" + (7 + 1) + "/" + 2000);
    }


    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.registerButton:

                registerUser();
                break;
            case R.id.genderRadioGroup:
                RadioGroup radioGroup = (RadioGroup) view;
                int checkedId = radioGroup.getCheckedRadioButtonId();
                onCheckedChanged(radioGroup, checkedId);
                break;
        }
    }

    private void onCheckedChanged(RadioGroup radioGroup, int checkedId) {
        RadioButton selectedRadioButton = findViewById(checkedId);
        String gender = selectedRadioButton.getText().toString();
    }



    private void registerUser() {
        String email = editTextEmail.getText().toString().trim();
        String password = editTextPassword.getText().toString().trim();
        String username = editTextUsername.getText().toString().trim();
        String phone = editTextPhone.getText().toString().trim();
        String date_of_birth = date.getText().toString().trim();
        String height = editTextHeight.getText().toString().trim();
        String weight = editTextWeight.getText().toString().trim();

        String gender = genderRadioGroup.getCheckedRadioButtonId() == R.id.radioFemale ? "Female" : "Male";


        if (username.isEmpty()) {
            editTextUsername.setError("Username required");
            editTextUsername.requestFocus();
            return;
        }
        if (email.isEmpty()) {
            editTextEmail.setError("Email required");
            editTextEmail.requestFocus();
            return;
        }
        if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            editTextEmail.setError("Please provide valid email!");
            editTextEmail.requestFocus();
            return;
        }

        if (date_of_birth.isEmpty()){
            date.setError("Dates Required");
            date.requestFocus();
            return;
        }
        if (phone.isEmpty()) {
            editTextPhone.setError("Phone Number required");
            editTextPhone.requestFocus();
            return;
        }

        if(!Patterns.PHONE.matcher(phone).matches()){
            editTextPhone.setError("Please enter a valid phone number!");
            editTextPhone.requestFocus();
            return;
        }


        if (password.isEmpty()) {
            editTextPassword.setError("Password required");
            editTextPassword.requestFocus();
            return;
        }
        if(password.length() < 6){
            editTextPassword.setError("Min password length should be 6 characters");
            editTextPassword.requestFocus();
            return;
        }

        System.out.println(gender);

        try {
           saveToFirebase(email, password, username, phone, date_of_birth, height, weight, gender);
           System.out.println("--------------------Hello----------------");
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

    }

    private void saveToFirebase(String email, String password, String username, String phone, String date_of_birth, String height, String weight, String gender) {
        mAuth.createUserWithEmailAndPassword(email, password)
                .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(Task<AuthResult> task) {

                        if(task.isSuccessful()){
                            try {
                                AsyncHttpClient client = new AsyncHttpClient();
                                JSONObject jsonParam = new JSONObject();
                                jsonParam.put("username",username);
                                jsonParam.put("firstName",username);
                                jsonParam.put("lastName",username);
                                jsonParam.put("email",email);
                                StringEntity entity = new StringEntity(jsonParam.toString());

                                client.post(getBaseContext(), Urls.ADD_USER, entity, "application/json", new BaseJsonHttpResponseHandler<Object>() {
                                    @Override
                                    public void onSuccess(int statusCode, Header[] headers, String rawJsonResponse, Object response) {
                                        System.out.println("Success");
                                        System.out.println(response);
                                        SpoonCularUserDTO userDTO = (SpoonCularUserDTO) response;

                                        User user = new User(username, email, phone, date_of_birth, weight, height, gender, userDTO.username, userDTO.spoonacularPassword,userDTO.hash);

                                        FirebaseDatabase.getInstance().getReference("Users")
                                                .child(FirebaseAuth.getInstance().getCurrentUser().getUid())
                                                .setValue(user).addOnCompleteListener(new OnCompleteListener<Void>() {
                                                    @Override
                                                    public void onComplete(Task<Void> task) {
                                                        if(task.isSuccessful()){
                                                            Toast.makeText(SignUp.this, "Account created successfully!", Toast.LENGTH_LONG).show();
                                                            startActivity(new Intent(SignUp.this, Home.class));
                                                        }
                                                        else{
                                                            System.out.println(task.getException().getMessage());
                                                            Toast.makeText(SignUp.this, "Registration failed - h ! Try again", Toast.LENGTH_LONG).show();
                                                        }
                                                    }
                                                });

                                    }

                                    @Override
                                    public void onFailure(int statusCode, Header[] headers, Throwable throwable, String rawJsonData, Object errorResponse) {

                                    }

                                    @Override
                                    protected Object parseResponse(String rawJsonData, boolean isFailure) throws Throwable {
                                        return SpoonCularUserDTO.getObject(rawJsonData);
                                    }
                                });

                            } catch (UnsupportedEncodingException | JSONException e) {
                                throw new RuntimeException(e);
                            }
                        }else{
                            Toast.makeText(SignUp.this, "Registration failed! Try again", Toast.LENGTH_LONG).show();
                        }
                    }
                });
    }

    //email, password, username, phone, date_of_birth, height, weight, gender
    private SpoonCularUserDTO registerSpooncularUser(String email, String password, String username, String phone, String date_of_birth, String height, String weight, String gender) throws Exception {
        AsyncHttpClient client = new AsyncHttpClient();
        RequestParams params = new RequestParams();
        JSONObject jsonParam = new JSONObject();
        jsonParam.put("username",username);
        jsonParam.put("firstName",username);
        jsonParam.put("lastName",username);
        jsonParam.put("email",email);

        StringEntity entity = new StringEntity(jsonParam.toString());
        ArrayList<SpoonCularUserDTO> list =new ArrayList<>();

        BaseJsonHttpResponseHandler handler =  new BaseJsonHttpResponseHandler<SpoonCularUserDTO>() {
            @Override
            public void onSuccess(int statusCode, Header[] headers, String rawJsonResponse, SpoonCularUserDTO response) {
                System.out.println(response);
                list.add(response);
                //                saveToFirebase(email, password, username, phone, date_of_birth, height, weight, gender, response);
            }

            @Override
            public void onFailure(int statusCode, Header[] headers, Throwable throwable, String rawJsonData, SpoonCularUserDTO errorResponse) {
                System.err.println(throwable.getMessage());
            }

            @Override
            protected SpoonCularUserDTO parseResponse(String rawJsonData, boolean isFailure) throws Throwable {
                if(isFailure){
                    return null;
                }
                return SpoonCularUserDTO.getObject(rawJsonData);
            }
        };




        RequestHandle requestHandle = client.post(getBaseContext(),Urls.ADD_USER, entity,"application/json",handler);
        
        return null;
    }

}


class SpoonCularUserDTO{
    String username;
    String spoonacularPassword;
    String hash;

    String status;

    public SpoonCularUserDTO() {
    }

    public SpoonCularUserDTO(String username, String password, String hash) {
        this.username = username;
        this.spoonacularPassword = password;
        this.hash = hash;
    }

    public static SpoonCularUserDTO getObject(String jsonData){
        try {
            JSONObject jsonObject = new JSONObject(jsonData);
            String username = jsonObject.getString("username");
            String password = jsonObject.getString("spoonacularPassword");
            String hash = jsonObject.getString("hash");

            return new SpoonCularUserDTO(username, password, hash);
        } catch (JSONException e) {
            System.out.println(e.getMessage());
        }
        return null;
    }


    @Override
    public String toString() {
        return "SpoonCularUserDTO{" +
                "username='" + username + '\'' +
                ", spoonacularPassword='" + spoonacularPassword + '\'' +
                ", hash='" + hash + '\'' +
                '}';
    }
}