package com.example.dietplan;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

import java.util.ArrayList;

public class MealPlan extends AppCompatActivity {
    private ArrayList<MealPlan> _mealPlans = new ArrayList<>(10);
    private MealPlan _selectedPlan = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_meal_plan);

        prepareMealPlans();

        final TextView _bmiLabel = findViewById(R.id.bmi_txt);
        final TextView _rciLabel = findViewById(R.id.rcc_txt);

        final TextView _breakfastLabel = findViewById(R.id.breakfast_summery_lbl);
        final TextView _lunchLabel = findViewById(R.id.lunch_summery_lbl);
        final TextView _dinnerLabel = findViewById(R.id.dinner_summery_lbl);


    }

    private void prepareMealPlans() {


    }
}