package com.example.dietplan;

public class Urls {
    public static String API = "3c4445d0536244488d4a3a7914765a8d";
    public static String ADD_USER = "https://api.spoonacular.com/users/connect?apiKey=" + API;
}
