package com.example.dietplan;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;


import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.time.LocalDate;
import java.time.Period;
import java.util.Date;

public class Profile extends AppCompatActivity {
    private FirebaseUser user;
    private DatabaseReference reference;
    private String userID;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        String dob;

        final ImageView back = findViewById(R.id.back);


        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Profile.this, Home.class);
                startActivity(intent);
            }
        });
        user = FirebaseAuth.getInstance().getCurrentUser();
        reference = FirebaseDatabase.getInstance().getReference("Users");
        userID = user.getUid();

        final TextView usernameTextView = (TextView) findViewById(R.id.username);
        final TextView phoneTextView = (TextView) findViewById(R.id.phone);
        final TextView emailTextView = (TextView) findViewById(R.id.email);
        final TextView weightTextView = (TextView) findViewById(R.id.weight);
        final TextView heightTextView = (TextView) findViewById(R.id.height);
        final TextView ageTextView = (TextView) findViewById(R.id.age);
        final TextView bmrTextView = (TextView) findViewById(R.id.bmr);
        final TextView bmiTextView = (TextView) findViewById(R.id.bmi);

        reference.child(userID).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                User userprofile = snapshot.getValue(User.class);

                if(userprofile != null){
                    String username = userprofile.username;
                    String email = userprofile.email;
                    String phone = userprofile.phone;
                    String weight = userprofile.weight;
                    String height = userprofile.height;
                    String dob = userprofile.date_of_birth;

                    Calendar dobDate = Calendar.getInstance();
                    SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
                    Date date = null;
                    try {
                        date = dateFormat.parse(dob);
                    } catch (ParseException e) {
                        throw new RuntimeException(e);
                    }
                    long timestamp = date.getTime();





                    Calendar currentDate = Calendar.getInstance();
                    int age = currentDate.get(Calendar.YEAR) - dobDate.get(Calendar.YEAR);
                    if (currentDate.get(Calendar.DAY_OF_YEAR) < dobDate.get(Calendar.DAY_OF_YEAR)){
                        age--;
                    }



                    usernameTextView.setText(username);
                    emailTextView.setText(email);
                    phoneTextView.setText(phone);
                    weightTextView.setText(weight);
                    heightTextView.setText(height);
                    ageTextView.setText(String.valueOf(age));


                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(Profile.this, "Something wrong happened!", Toast.LENGTH_LONG).show();
            }
        });



    }
}