package com.example.dietplan;

import java.io.Serializable;

public class MealPlan_model implements Serializable {
    private String _name;
    private Meal _breakfast;
    private Meal _lunch;
    private Meal _dinner;

    private Double _calories;

    public MealPlan_model(String name, Meal breakfast, Meal lunch, Meal dinner){
        _name = name;
        _breakfast = breakfast;
        _lunch = lunch;
        _dinner = dinner;

        _calories = _breakfast.getCalories() + _lunch.getCalories() + _dinner.getCalories();
    }
    public Meal getBreakfast() {
        return _breakfast;
    }

    public Meal getLunch() {
        return _lunch;
    }

    public Meal getDinner() {
        return _dinner;
    }

    public Double getTotalCalories() {
        return _calories;
    }
}
