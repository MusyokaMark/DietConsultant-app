package com.example.dietplan;

public class User {
    public String email, username,phone, date_of_birth, weight, height, gender, spoonacularUsername, spoonacularPassword, hash;


    public User(){

    }
    public User(String username, String email, String phone, String date_of_birth, String weight, String height, String gender) {
        this.email = email;
        this.username = username;
        this.phone = phone;
        this.weight = weight;
        this.height = height;
        this.date_of_birth = date_of_birth;
        this.gender = gender;
    }


    public User(String username, String email, String phone, String date_of_birth, String weight, String height, String gender, String username1, String spoonacularPassword, String hash) {
        this.email = email;
        this.username = username;
        this.phone = phone;
        this.weight = weight;
        this.height = height;
        this.date_of_birth = date_of_birth;
        this.gender = gender;
        this.spoonacularPassword = spoonacularPassword;
        this.spoonacularUsername = username1;
        this.hash = hash;
    }
}
