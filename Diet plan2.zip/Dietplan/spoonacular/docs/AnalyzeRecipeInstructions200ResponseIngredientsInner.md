

# AnalyzeRecipeInstructions200ResponseIngredientsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | [**BigDecimal**](BigDecimal.md) |  | 
**name** | **String** |  | 




