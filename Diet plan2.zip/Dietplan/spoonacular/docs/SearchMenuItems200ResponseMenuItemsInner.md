

# SearchMenuItems200ResponseMenuItemsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** |  | 
**title** | **String** |  | 
**restaurantChain** | **String** |  | 
**image** | **String** |  | 
**imageType** | **String** |  | 
**servings** | [**SearchGroceryProductsByUPC200ResponseServings**](SearchGroceryProductsByUPC200ResponseServings.md) |  |  [optional]




