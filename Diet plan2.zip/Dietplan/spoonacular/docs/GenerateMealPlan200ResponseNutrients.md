

# GenerateMealPlan200ResponseNutrients

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**calories** | [**BigDecimal**](BigDecimal.md) |  | 
**carbohydrates** | [**BigDecimal**](BigDecimal.md) |  | 
**fat** | [**BigDecimal**](BigDecimal.md) |  | 
**protein** | [**BigDecimal**](BigDecimal.md) |  | 




