

# GuessNutritionByDishName200ResponseCaloriesConfidenceRange95Percent

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**max** | [**BigDecimal**](BigDecimal.md) |  | 
**min** | [**BigDecimal**](BigDecimal.md) |  | 




