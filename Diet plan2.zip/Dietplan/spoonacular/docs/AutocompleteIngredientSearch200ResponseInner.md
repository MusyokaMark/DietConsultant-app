

# AutocompleteIngredientSearch200ResponseInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** |  | 
**image** | **String** |  | 
**id** | **Integer** |  |  [optional]
**aisle** | **String** |  |  [optional]
**possibleUnits** | **List&lt;String&gt;** |  |  [optional]




