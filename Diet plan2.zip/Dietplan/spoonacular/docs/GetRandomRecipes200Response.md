

# GetRandomRecipes200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**recipes** | [**Set&lt;GetRandomRecipes200ResponseRecipesInner&gt;**](GetRandomRecipes200ResponseRecipesInner.md) |  | 




