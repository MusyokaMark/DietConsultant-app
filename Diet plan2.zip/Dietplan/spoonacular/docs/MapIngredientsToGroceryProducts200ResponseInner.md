

# MapIngredientsToGroceryProducts200ResponseInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**original** | **String** |  | 
**originalName** | **String** |  | 
**ingredientImage** | **String** |  | 
**meta** | **List&lt;String&gt;** |  | 
**products** | [**Set&lt;MapIngredientsToGroceryProducts200ResponseInnerProductsInner&gt;**](MapIngredientsToGroceryProducts200ResponseInnerProductsInner.md) |  | 




