

# AddToMealPlanRequest1

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**date** | [**BigDecimal**](BigDecimal.md) |  | 
**slot** | **Integer** |  | 
**position** | **Integer** |  | 
**type** | **String** |  | 
**value** | [**AddToMealPlanRequest1Value**](AddToMealPlanRequest1Value.md) |  | 




