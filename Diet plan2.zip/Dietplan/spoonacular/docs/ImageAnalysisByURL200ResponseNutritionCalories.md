

# ImageAnalysisByURL200ResponseNutritionCalories

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**value** | [**BigDecimal**](BigDecimal.md) |  | 
**unit** | **String** |  | 
**confidenceRange95Percent** | [**ImageAnalysisByURL200ResponseNutritionCaloriesConfidenceRange95Percent**](ImageAnalysisByURL200ResponseNutritionCaloriesConfidenceRange95Percent.md) |  | 
**standardDeviation** | [**BigDecimal**](BigDecimal.md) |  | 




