

# ClassifyGroceryProductBulkRequestInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**title** | **String** |  | 
**upc** | **String** |  | 
**pluCode** | **String** |  | 




