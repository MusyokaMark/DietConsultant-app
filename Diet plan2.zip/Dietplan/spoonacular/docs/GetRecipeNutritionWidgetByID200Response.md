

# GetRecipeNutritionWidgetByID200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**calories** | **String** |  | 
**carbs** | **String** |  | 
**fat** | **String** |  | 
**protein** | **String** |  | 
**bad** | [**Set&lt;GetRecipeNutritionWidgetByID200ResponseBadInner&gt;**](GetRecipeNutritionWidgetByID200ResponseBadInner.md) |  | 
**good** | [**Set&lt;GetRecipeNutritionWidgetByID200ResponseGoodInner&gt;**](GetRecipeNutritionWidgetByID200ResponseGoodInner.md) |  | 




