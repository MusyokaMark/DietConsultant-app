

# GetWinePairing200ResponseProductMatchesInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** |  | 
**title** | **String** |  | 
**averageRating** | [**BigDecimal**](BigDecimal.md) |  | 
**description** | [**OasAnyTypeNotMapped**](.md) |  |  [optional]
**imageUrl** | **String** |  | 
**link** | **String** |  | 
**price** | **String** |  | 
**ratingCount** | **Integer** |  | 
**score** | [**BigDecimal**](BigDecimal.md) |  | 




