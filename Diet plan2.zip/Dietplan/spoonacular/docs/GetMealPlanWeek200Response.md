

# GetMealPlanWeek200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**days** | [**Set&lt;GetMealPlanWeek200ResponseDaysInner&gt;**](GetMealPlanWeek200ResponseDaysInner.md) |  | 




