

# ParseIngredients200ResponseInnerNutritionCaloricBreakdown

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**percentProtein** | [**BigDecimal**](BigDecimal.md) |  | 
**percentFat** | [**BigDecimal**](BigDecimal.md) |  | 
**percentCarbs** | [**BigDecimal**](BigDecimal.md) |  | 




