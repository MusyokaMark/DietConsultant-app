

# SearchSiteContent200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**articles** | [**Set&lt;SearchSiteContent200ResponseArticlesInner&gt;**](SearchSiteContent200ResponseArticlesInner.md) |  | 
**groceryProducts** | [**Set&lt;SearchSiteContent200ResponseGroceryProductsInner&gt;**](SearchSiteContent200ResponseGroceryProductsInner.md) |  | 
**menuItems** | [**Set&lt;SearchSiteContent200ResponseGroceryProductsInner&gt;**](SearchSiteContent200ResponseGroceryProductsInner.md) |  | 
**recipes** | [**Set&lt;SearchSiteContent200ResponseGroceryProductsInner&gt;**](SearchSiteContent200ResponseGroceryProductsInner.md) |  | 




