

# AnalyzeRecipeInstructions200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**parsedInstructions** | [**Set&lt;AnalyzeRecipeInstructions200ResponseParsedInstructionsInner&gt;**](AnalyzeRecipeInstructions200ResponseParsedInstructionsInner.md) |  | 
**ingredients** | [**Set&lt;AnalyzeRecipeInstructions200ResponseIngredientsInner&gt;**](AnalyzeRecipeInstructions200ResponseIngredientsInner.md) |  | 
**equipment** | [**Set&lt;AnalyzeRecipeInstructions200ResponseIngredientsInner&gt;**](AnalyzeRecipeInstructions200ResponseIngredientsInner.md) |  | 




