

# ConnectUser200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**username** | **String** |  | 
**hash** | **String** |  | 




