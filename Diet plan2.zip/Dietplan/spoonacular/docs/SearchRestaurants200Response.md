

# SearchRestaurants200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**restaurants** | [**List&lt;SearchRestaurants200ResponseRestaurantsInner&gt;**](SearchRestaurants200ResponseRestaurantsInner.md) |  |  [optional]




