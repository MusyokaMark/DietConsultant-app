

# SearchSiteContent200ResponseArticlesInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**dataPoints** | [**List&lt;OasAnyTypeNotMapped&gt;**](OasAnyTypeNotMapped.md) |  |  [optional]
**image** | **String** |  | 
**link** | **String** |  | 
**name** | **String** |  | 




