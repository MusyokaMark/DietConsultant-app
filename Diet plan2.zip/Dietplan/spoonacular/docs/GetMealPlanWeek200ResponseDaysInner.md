

# GetMealPlanWeek200ResponseDaysInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**nutritionSummary** | [**GetMealPlanWeek200ResponseDaysInnerNutritionSummary**](GetMealPlanWeek200ResponseDaysInnerNutritionSummary.md) |  |  [optional]
**nutritionSummaryBreakfast** | [**GetMealPlanWeek200ResponseDaysInnerNutritionSummary**](GetMealPlanWeek200ResponseDaysInnerNutritionSummary.md) |  |  [optional]
**nutritionSummaryLunch** | [**GetMealPlanWeek200ResponseDaysInnerNutritionSummary**](GetMealPlanWeek200ResponseDaysInnerNutritionSummary.md) |  |  [optional]
**nutritionSummaryDinner** | [**GetMealPlanWeek200ResponseDaysInnerNutritionSummary**](GetMealPlanWeek200ResponseDaysInnerNutritionSummary.md) |  |  [optional]
**date** | [**BigDecimal**](BigDecimal.md) |  | 
**day** | **String** |  | 
**items** | [**Set&lt;GetMealPlanWeek200ResponseDaysInnerItemsInner&gt;**](GetMealPlanWeek200ResponseDaysInnerItemsInner.md) |  |  [optional]




