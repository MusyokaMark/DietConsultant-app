

# GetMealPlanTemplate200ResponseDaysInnerItemsInnerValue

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | [**BigDecimal**](BigDecimal.md) |  | 
**title** | **String** |  | 
**imageType** | **String** |  | 




