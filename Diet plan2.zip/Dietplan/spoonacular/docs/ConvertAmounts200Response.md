

# ConvertAmounts200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**sourceAmount** | [**BigDecimal**](BigDecimal.md) |  | 
**sourceUnit** | **String** |  | 
**targetAmount** | [**BigDecimal**](BigDecimal.md) |  | 
**targetUnit** | **String** |  | 
**answer** | **String** |  | 




