

# ComputeGlycemicLoad200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**totalGlycemicLoad** | [**BigDecimal**](BigDecimal.md) |  | 
**ingredients** | [**Set&lt;ComputeGlycemicLoad200ResponseIngredientsInner&gt;**](ComputeGlycemicLoad200ResponseIngredientsInner.md) |  | 




