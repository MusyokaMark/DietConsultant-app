

# GetComparableProducts200ResponseComparableProductsProteinInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**difference** | [**BigDecimal**](BigDecimal.md) |  | 
**id** | **Integer** |  | 
**image** | **String** |  | 
**title** | **String** |  | 




