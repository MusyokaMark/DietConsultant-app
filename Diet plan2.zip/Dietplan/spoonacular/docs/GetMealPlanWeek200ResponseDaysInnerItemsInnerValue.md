

# GetMealPlanWeek200ResponseDaysInnerItemsInnerValue

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**servings** | [**BigDecimal**](BigDecimal.md) |  | 
**id** | [**BigDecimal**](BigDecimal.md) |  | 
**title** | **String** |  | 
**imageType** | **String** |  | 




