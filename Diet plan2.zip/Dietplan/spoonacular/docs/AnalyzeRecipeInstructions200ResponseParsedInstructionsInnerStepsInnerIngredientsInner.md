

# AnalyzeRecipeInstructions200ResponseParsedInstructionsInnerStepsInnerIngredientsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | [**BigDecimal**](BigDecimal.md) |  | 
**name** | **String** |  | 
**localizedName** | **String** |  | 
**image** | **String** |  | 




