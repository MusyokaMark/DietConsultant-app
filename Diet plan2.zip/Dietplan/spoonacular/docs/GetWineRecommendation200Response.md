

# GetWineRecommendation200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**recommendedWines** | [**Set&lt;GetWineRecommendation200ResponseRecommendedWinesInner&gt;**](GetWineRecommendation200ResponseRecommendedWinesInner.md) |  | 
**totalFound** | **Integer** |  | 




