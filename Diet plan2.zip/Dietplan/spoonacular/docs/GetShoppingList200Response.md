

# GetShoppingList200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**aisles** | [**Set&lt;GetShoppingList200ResponseAislesInner&gt;**](GetShoppingList200ResponseAislesInner.md) |  | 
**cost** | [**BigDecimal**](BigDecimal.md) |  | 
**startDate** | [**BigDecimal**](BigDecimal.md) |  | 
**endDate** | [**BigDecimal**](BigDecimal.md) |  | 




