

# ParseIngredients200ResponseInnerNutritionNutrientsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** |  | 
**amount** | [**BigDecimal**](BigDecimal.md) |  | 
**unit** | **String** |  | 
**percentOfDailyNeeds** | [**BigDecimal**](BigDecimal.md) |  | 




