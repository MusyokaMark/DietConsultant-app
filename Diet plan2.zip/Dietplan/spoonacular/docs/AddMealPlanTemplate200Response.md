

# AddMealPlanTemplate200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** |  | 
**items** | [**Set&lt;AddMealPlanTemplate200ResponseItemsInner&gt;**](AddMealPlanTemplate200ResponseItemsInner.md) |  | 
**publishAsPublic** | **Boolean** |  | 




