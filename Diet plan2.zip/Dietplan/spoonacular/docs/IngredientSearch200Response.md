

# IngredientSearch200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**results** | [**Set&lt;IngredientSearch200ResponseResultsInner&gt;**](IngredientSearch200ResponseResultsInner.md) |  | 
**offset** | **Integer** |  | 
**number** | **Integer** |  | 
**totalResults** | **Integer** |  | 




