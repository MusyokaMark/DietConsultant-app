

# ComputeGlycemicLoad200ResponseIngredientsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** |  | 
**original** | **String** |  | 
**glycemicIndex** | [**BigDecimal**](BigDecimal.md) |  | 
**glycemicLoad** | [**BigDecimal**](BigDecimal.md) |  | 




