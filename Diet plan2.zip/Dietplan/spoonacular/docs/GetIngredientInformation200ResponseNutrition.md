

# GetIngredientInformation200ResponseNutrition

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**nutrients** | [**Set&lt;ParseIngredients200ResponseInnerNutritionNutrientsInner&gt;**](ParseIngredients200ResponseInnerNutritionNutrientsInner.md) |  | 
**properties** | [**Set&lt;ParseIngredients200ResponseInnerNutritionPropertiesInner&gt;**](ParseIngredients200ResponseInnerNutritionPropertiesInner.md) |  | 
**caloricBreakdown** | [**ParseIngredients200ResponseInnerNutritionCaloricBreakdown**](ParseIngredients200ResponseInnerNutritionCaloricBreakdown.md) |  | 
**weightPerServing** | [**ParseIngredients200ResponseInnerNutritionWeightPerServing**](ParseIngredients200ResponseInnerNutritionWeightPerServing.md) |  | 




