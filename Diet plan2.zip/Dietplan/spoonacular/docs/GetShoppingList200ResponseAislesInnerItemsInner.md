

# GetShoppingList200ResponseAislesInnerItemsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** |  | 
**name** | **String** |  | 
**measures** | [**GetShoppingList200ResponseAislesInnerItemsInnerMeasures**](GetShoppingList200ResponseAislesInnerItemsInnerMeasures.md) |  |  [optional]
**pantryItem** | **Boolean** |  | 
**aisle** | **String** |  | 
**cost** | [**BigDecimal**](BigDecimal.md) |  | 
**ingredientId** | **Integer** |  | 




